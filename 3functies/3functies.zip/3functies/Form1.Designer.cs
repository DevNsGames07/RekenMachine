﻿namespace _3functies
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.getal1_textBox1 = new System.Windows.Forms.TextBox();
            this.getal2_textBox2 = new System.Windows.Forms.TextBox();
            this.getal3_textBox3 = new System.Windows.Forms.TextBox();
            this.antwoord1_textBox4 = new System.Windows.Forms.TextBox();
            this.antwoord2_textBox5 = new System.Windows.Forms.TextBox();
            this.antwoord3_textBox6 = new System.Windows.Forms.TextBox();
            this.getal3_label1 = new System.Windows.Forms.Label();
            this.getal2_label2 = new System.Windows.Forms.Label();
            this.getal1_label3 = new System.Windows.Forms.Label();
            this.driedubbel_label4 = new System.Windows.Forms.Label();
            this.verdubbel_label5 = new System.Windows.Forms.Label();
            this.max_label6 = new System.Windows.Forms.Label();
            this.antwoorden_button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // getal1_textBox1
            // 
            this.getal1_textBox1.Location = new System.Drawing.Point(315, 158);
            this.getal1_textBox1.Name = "getal1_textBox1";
            this.getal1_textBox1.Size = new System.Drawing.Size(100, 22);
            this.getal1_textBox1.TabIndex = 0;
            this.getal1_textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // getal2_textBox2
            // 
            this.getal2_textBox2.Location = new System.Drawing.Point(315, 186);
            this.getal2_textBox2.Name = "getal2_textBox2";
            this.getal2_textBox2.Size = new System.Drawing.Size(100, 22);
            this.getal2_textBox2.TabIndex = 1;
            this.getal2_textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // getal3_textBox3
            // 
            this.getal3_textBox3.Location = new System.Drawing.Point(315, 214);
            this.getal3_textBox3.Name = "getal3_textBox3";
            this.getal3_textBox3.Size = new System.Drawing.Size(100, 22);
            this.getal3_textBox3.TabIndex = 2;
            this.getal3_textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // antwoord1_textBox4
            // 
            this.antwoord1_textBox4.Location = new System.Drawing.Point(546, 145);
            this.antwoord1_textBox4.Name = "antwoord1_textBox4";
            this.antwoord1_textBox4.ReadOnly = true;
            this.antwoord1_textBox4.Size = new System.Drawing.Size(100, 22);
            this.antwoord1_textBox4.TabIndex = 3;
            this.antwoord1_textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // antwoord2_textBox5
            // 
            this.antwoord2_textBox5.Location = new System.Drawing.Point(546, 199);
            this.antwoord2_textBox5.Name = "antwoord2_textBox5";
            this.antwoord2_textBox5.ReadOnly = true;
            this.antwoord2_textBox5.Size = new System.Drawing.Size(100, 22);
            this.antwoord2_textBox5.TabIndex = 4;
            this.antwoord2_textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // antwoord3_textBox6
            // 
            this.antwoord3_textBox6.Location = new System.Drawing.Point(546, 257);
            this.antwoord3_textBox6.Name = "antwoord3_textBox6";
            this.antwoord3_textBox6.ReadOnly = true;
            this.antwoord3_textBox6.Size = new System.Drawing.Size(100, 22);
            this.antwoord3_textBox6.TabIndex = 5;
            this.antwoord3_textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // getal3_label1
            // 
            this.getal3_label1.AutoSize = true;
            this.getal3_label1.Location = new System.Drawing.Point(241, 214);
            this.getal3_label1.Name = "getal3_label1";
            this.getal3_label1.Size = new System.Drawing.Size(44, 16);
            this.getal3_label1.TabIndex = 6;
            this.getal3_label1.Text = "getal3";
            // 
            // getal2_label2
            // 
            this.getal2_label2.AutoSize = true;
            this.getal2_label2.Location = new System.Drawing.Point(241, 186);
            this.getal2_label2.Name = "getal2_label2";
            this.getal2_label2.Size = new System.Drawing.Size(44, 16);
            this.getal2_label2.TabIndex = 7;
            this.getal2_label2.Text = "getal2";
            // 
            // getal1_label3
            // 
            this.getal1_label3.AutoSize = true;
            this.getal1_label3.Location = new System.Drawing.Point(241, 158);
            this.getal1_label3.Name = "getal1_label3";
            this.getal1_label3.Size = new System.Drawing.Size(44, 16);
            this.getal1_label3.TabIndex = 8;
            this.getal1_label3.Text = "getal1";
            // 
            // driedubbel_label4
            // 
            this.driedubbel_label4.AutoSize = true;
            this.driedubbel_label4.Location = new System.Drawing.Point(546, 177);
            this.driedubbel_label4.Name = "driedubbel_label4";
            this.driedubbel_label4.Size = new System.Drawing.Size(142, 16);
            this.driedubbel_label4.TabIndex = 9;
            this.driedubbel_label4.Text = "Kwadrateer getal twee:";
            // 
            // verdubbel_label5
            // 
            this.verdubbel_label5.AutoSize = true;
            this.verdubbel_label5.Location = new System.Drawing.Point(546, 123);
            this.verdubbel_label5.Name = "verdubbel_label5";
            this.verdubbel_label5.Size = new System.Drawing.Size(137, 16);
            this.verdubbel_label5.TabIndex = 10;
            this.verdubbel_label5.Text = "Kwadrateer getal een:";
            // 
            // max_label6
            // 
            this.max_label6.AutoSize = true;
            this.max_label6.Location = new System.Drawing.Point(546, 235);
            this.max_label6.Name = "max_label6";
            this.max_label6.Size = new System.Drawing.Size(177, 16);
            this.max_label6.TabIndex = 11;
            this.max_label6.Text = "Vindt maximum uit 3 getallen:";
            // 
            // antwoorden_button1
            // 
            this.antwoorden_button1.Location = new System.Drawing.Point(274, 269);
            this.antwoorden_button1.Name = "antwoorden_button1";
            this.antwoorden_button1.Size = new System.Drawing.Size(157, 23);
            this.antwoorden_button1.TabIndex = 12;
            this.antwoorden_button1.Text = "Voer 3 functies uit";
            this.antwoorden_button1.UseVisualStyleBackColor = true;
            this.antwoorden_button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.antwoorden_button1);
            this.Controls.Add(this.max_label6);
            this.Controls.Add(this.verdubbel_label5);
            this.Controls.Add(this.driedubbel_label4);
            this.Controls.Add(this.getal1_label3);
            this.Controls.Add(this.getal2_label2);
            this.Controls.Add(this.getal3_label1);
            this.Controls.Add(this.antwoord3_textBox6);
            this.Controls.Add(this.antwoord2_textBox5);
            this.Controls.Add(this.antwoord1_textBox4);
            this.Controls.Add(this.getal3_textBox3);
            this.Controls.Add(this.getal2_textBox2);
            this.Controls.Add(this.getal1_textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox getal1_textBox1;
        private System.Windows.Forms.TextBox getal2_textBox2;
        private System.Windows.Forms.TextBox getal3_textBox3;
        private System.Windows.Forms.TextBox antwoord1_textBox4;
        private System.Windows.Forms.TextBox antwoord2_textBox5;
        private System.Windows.Forms.TextBox antwoord3_textBox6;
        private System.Windows.Forms.Label getal3_label1;
        private System.Windows.Forms.Label getal2_label2;
        private System.Windows.Forms.Label getal1_label3;
        private System.Windows.Forms.Label driedubbel_label4;
        private System.Windows.Forms.Label verdubbel_label5;
        private System.Windows.Forms.Label max_label6;
        private System.Windows.Forms.Button antwoorden_button1;
    }
}

